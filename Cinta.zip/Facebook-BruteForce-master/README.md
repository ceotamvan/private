# Facebook-BruteForce
bruteforce attack on facebook account script in python

## Install Requirements(Linux)
* apt-get install git python3 python3-pip

## Run commands one by one
* git clone https://github.com/IAmBlackHacker/Facebook-BruteForce
* cd Facebook-BruteForce
* pip3 install requests bs4
* python3 fb.py

## Screenshots
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture1.JPG)
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture2.JPG)
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture3.JPG)

## Protection Against Attacker
* Use Strong Password(Contain all chars + longest as possible)
* Use two way authentication.
* Make location based login(+browser based).

## Explore More in Hacking ...
https://www.facebook.com/B14CKH4K3R/

~~~
Happy Hacking Day ! (Please do not spam it, It's Just For Knowledge ...).
~~~
